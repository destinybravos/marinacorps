<template>
    <div id="services_page">
        <section>
            <h2 class="mt-5" data-aos="fade-up">  
                EXPRESS LOGISTICS AND COURIER SERVICES
            </h2>
            <p class="my-3" data-aos="fade-up">
                For us moving your consignment from one destination to the other is equivalent to ensuring your 
                reputation, travels far and wide, unblemished.
            </p>
        </section>

        <div class="container">
            <div class="row my-5">
                <div class="col-md-6" data-aos="fade-up-right">
                    <img src="/img/air_cargo.jpg" alt=" " style="max-width:100%;">
                </div>
                <div class="col-md-6 service_details" data-aos="fade-up-left">
                    <h2>Air Freight</h2>
                    <p>
                        Express logistics and courier service provides, top notch, hassle free and timely movement for all your consignments 
                        through our air Freight services at very 
                        competitive rates. We strive hard to ensure that you are ably guided through out the process that involves 
                        packing, document filing, clearance from customs, loading until the very last step of delivering. We are 
                        thoroughly prepared for;
                    </p>
                    <p>
                        <ul>
                            <li>
                                Immediate Deliveries on the Next Flight Out
                            </li>
                            <li>
                                Time Definite Express Service
                            </li>
                            <li>
                                Personal Door to Door Service or Airport to Airport service
                            </li>
                            <li>
                                Consolidation and Direct to Consignee Service
                            </li>
                            <li>
                                Competitive Deferred Air Freight Service
                            </li>
                            <li>
                               Overnight Service 
                            </li>
                        </ul>
                    </p>
                </div>
            </div>

            <div class="row my-5 odd">
                <div class="col-md-6" data-aos="fade-up-right">
                    <img src="/img/ocean_shipping.jpg" alt=" " style="max-width:100%;">
                </div>
                <div class="col-md-6 service_details" data-aos="fade-up-left">
                    <h2>Ocean Freight</h2>
                    <p>
                        We also provides a holistic solution to transport your bulky and gigantic cargo through water ways, 
                        eclipsing territories and regions. Our qualified, trained, professional workforce ensures that your 
                        consignment no matter how big or heavy finds adequate space, fulfills all requisitions for different 
                        countries and is set to sail as per schedule. We have a firm grip on the following;
                    </p>
                    <p>
                        <ul>
                            <li>
                                Direct Consolidation Covering More Than 350 Destinations Worldwide
                            </li>
                            <li>
                                Fixed Cut Offs with Assured Sailings
                            </li>
                            <li>
                                Dedicated CFS at all FSL Gateways
                            </li>
                            <li>
                                Digitized Booking & Loading Confirmation
                            </li>
                        </ul>
                    </p>
                </div>
            </div>
            
            <div class="row my-5">
                <div class="col-md-6" data-aos="fade-up-right">
                    <img src="/img/logistic_vehicles.jpg" alt=" " style="max-width:100%; padding:20px 0">
                </div>
                <div class="col-md-6 service_details" data-aos="fade-up-left">
                    <h2>Road and Rail Services</h2>
                    <p>
                        Need a fleet of trucks or trian to transport containers from your manufacturing unit to the dock or airport? 
                        Looking at penetrating deep inside to far flung locations to make final delivery? Unsure about the quality of 
                        transport and safety of your goods?
                    </p>
                    <p>
                        We have an expansive network of owned and leased vehicles as well as rail transport partners, capable of 
                        safe and timely deliveries. Our stringent policies ensure that the vehicles used for transport are 
                        maintained in prime condition to avoid delays due to vehicle break down or any other adverse situation. 
                        Our handpicked, verified driving staff is well trained and equipped to drive long hours and respect 
                        commitments.
                    </p>
                </div>
            </div>

            <div class="row my-5 odd">
                <div class="col-md-6" data-aos="fade-up-right">
                    <img src="/img/brokerage.jpg" alt=" " style="max-width:100%;">
                </div>
                <div class="col-md-6 service_details" data-aos="fade-up-left">
                    <h2>Customs Brokerage</h2>
                    <p>
                        We also have recruited a lot of personels who are the sharpest and the smartest minds to 
                        work alongside in our team. Some of these professionals are individuals with years of 
                        experience in the export/import business, understanding the in and out, no matter what the 
                        situation. Their sole aim is to ensure that our clients are not hassled, and consignments 
                        set for arrival or departure move as per schedules.
                    </p>
                    <h4>They are resposible for;</h4>
                    <p>
                        <ul>
                            <li>Retainer Consultancy / Customs compliances</li>
                            <li>AEO certification for Exporter / Importer and logistic service provider</li>
                            <li>Certificate of BIS, WPC , EPR & ETA</li>
                            <li>Customs Advisories</li>
                            <li>Customs and GST appeals</li>
                        </ul>
                    </p>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    
}
</script>

<style scoped>
    #services_page section{
        max-width: 93%;
        margin: auto auto 50px;
        text-align: center;
    }
    #services_page h2{
        font-weight: 900;
        /* font-size: 2.5rem; */
        color:#261c6a;
        text-align: center;
    }
    #services_page section p{
        font-size: 1.2rem;
    }
    .service_details h2{
        padding: 20px 0;
        background-color: #261c6a;
        background-image: url('/img/shapes-dark.jpg');
        color: white !important;
    }
    .odd{
        flex-direction: row-reverse;
    }
</style>