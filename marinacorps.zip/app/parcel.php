<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class parcel extends Model
{
    //
}
