<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class apply_leave extends Model
{
    //
}
