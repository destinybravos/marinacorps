<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SupportEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    protected $request;
    public function __construct($request)
    {
        //Accept all the request data
        $this->request = $request;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from($this->request->sender)
                    ->view('email.support', [
                        'message'=>$this->request->message
                        ])
                    ->subject($this->request->subject);
        // return $this->markdown('email.support', [
        //     'message'=>$this->request->message
        //     ])->from($this->request->sender)->subject($this->request->subject);
    }
}
