@extends('layouts.app')

@section('content')
    <apply-component></apply-component>
@endsection