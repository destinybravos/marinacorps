@extends('layouts.app')

@section('content')
    <index-component></index-component>

    
@endsection
