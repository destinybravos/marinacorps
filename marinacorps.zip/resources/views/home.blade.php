@extends('layouts.auth_layout')

@section('content')
<dashboard-component></dashboard-component>
@endsection
