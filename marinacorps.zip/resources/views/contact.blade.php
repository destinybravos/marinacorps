@extends('layouts.app')

@section('content')
    <contact-component></contact-component>
@endsection
