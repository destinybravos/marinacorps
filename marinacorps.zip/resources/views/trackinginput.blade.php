@extends('layouts.app')

@section('content')
    <trackinginput-component></trackinginput-component>
@endsection
