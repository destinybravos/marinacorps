@extends('layouts.app')

@section('content')
    <tracking-component></tracking-component>
@endsection
