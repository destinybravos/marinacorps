@extends('layouts.app')

@section('content')
    <services-component></services-component>
@endsection
