@extends('layouts.app')

@section('content')
    <about-component></about-component>
@endsection
