$('body').on('click', '.navbar-toggler', function(ev){
    let sideBar = $('#side_bar');
    sideBar.toggleClass('open')
});
