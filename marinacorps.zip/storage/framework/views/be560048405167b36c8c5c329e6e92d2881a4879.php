<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        

        <?php if(Route::has('password.request')): ?>
            <login-component reset-password-link="<?php echo e(route('password.request')); ?>"></login-component>
        <?php else: ?>
            <login-component></login-component>
        <?php endif; ?>
        

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\marinacorps\resources\views/auth/login.blade.php ENDPATH**/ ?>