<?php $__env->startSection('content'); ?>
<dashboard-component></dashboard-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\marinacorps\resources\views/home.blade.php ENDPATH**/ ?>