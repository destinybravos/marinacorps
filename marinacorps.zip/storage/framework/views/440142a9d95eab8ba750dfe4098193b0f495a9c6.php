

<?php $__env->startSection('content'); ?>
    <trackinginput-component></trackinginput-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exlogcourier\resources\views/trackinginput.blade.php ENDPATH**/ ?>